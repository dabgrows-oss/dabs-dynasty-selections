
export default function Shop() {
  return (
    <main style={{padding:'40px', fontFamily:'sans-serif'}}>
      <h1>Shop Seeds</h1>
      <div>
        <h3>Phantom Breath F2</h3>
        <p>Mendo Breath x Dark Hollow</p>
        <a href="/checkout">Add to Cart</a>
      </div>
    </main>
  )
}
